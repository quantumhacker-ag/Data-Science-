# 🏏 IPL Matches Analysis (2008–2016)

Exploratory data analysis of **577 Indian Premier League matches** using Python (pandas, matplotlib, seaborn).

## Questions answered
- Does winning the toss help win the match?
- Which teams are most successful? Who wins head-to-head?
- Is it better to bat first or chase?
- Which venues and cities host the most matches? Is there a home advantage?
- Who wins the most Player-of-the-Match awards?

## Key findings
| # | Finding |
|---|---------|
| 1 | Toss winner wins the match only **50.7%** of the time – toss gives almost no edge. |
| 2 | Captains choose to **field 55%** of the time; chasing teams win **54.0%** of decided matches. |
| 3 | **Mumbai Indians** have most wins (80); **Chennai Super Kings** best win rate (60.3%). |
| 4 | Home advantage is largest for Rajasthan Royals (+26 pts) and Kolkata Knight Riders (+22 pts); Delhi Daredevils won *less* at home. |
| 5 | **M Chinnaswamy Stadium** hosted the most matches (58). |
| 6 | **CH Gayle** has most Player-of-the-Match awards (17). |
| 7 | Title winners 2008–16: CSK, KKR, MI (2 each); RR, Deccan Chargers, SRH (1 each). |

![Team wins](images/team_wins.png)
![Home advantage](images/home_advantage.png)

## Repository structure
```
ipl-analysis/
├── data/ipl_matches_cleaned.xlsx   # source dataset (577 rows × 17 cols)
├── images/                         # charts exported by the notebook
├── ipl_analysis.ipynb              # full analysis (executed, outputs included)
├── requirements.txt
└── README.md
```

## Dataset columns
`id, season, city, date, team1, team2, toss_winner, toss_decision, result, dl_applied, winner, win_by_runs, win_by_wickets, player_of_match, venue, umpire1, umpire2`

## Run
```bash
cd ipl-analysis
pip install -r requirements.txt
jupyter notebook ipl_analysis.ipynb
```
The notebook finds the dataset in `data/` or next to itself (also works in Google Colab after uploading the xlsx).

## Notes & limitations
- Data covers seasons 2008–2016 only.
- "Home" is approximated by the franchise's home city; neutral/relocated venues count as away.
- Season champion = winner of the last match of each season.
